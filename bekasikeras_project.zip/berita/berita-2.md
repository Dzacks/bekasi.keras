
---
title: "Cerita Inspirasi dari Bekasi"
date: 2025-04-27
---

Di balik kerasnya, Bekasi menyimpan banyak kisah inspiratif tentang perjuangan dan keberanian.
