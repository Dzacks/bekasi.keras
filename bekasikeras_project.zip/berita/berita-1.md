
---
title: "Kerasnya Jalanan Bekasi"
date: 2025-04-28
---

Bekasi adalah tempat di mana panas dan perjuangan bertemu. Jalanan yang keras membentuk karakter warganya.
